/* ═══════════════════════════════════════════════════════════════
   BioMatch AI — app.js
   Full frontend logic: canvas bg, live sequence analysis, API calls
   ═══════════════════════════════════════════════════════════════ */

const API = 'http://localhost:8000';

/* ─── CANVAS BACKGROUND ─────────────────────────────────────────── */
(function initCanvas() {
  const canvas = document.getElementById('bgCanvas');
  const ctx = canvas.getContext('2d');

  let W, H, particles = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  // Floating DNA base letters
  const BASES = ['A', 'T', 'G', 'C'];
  const COLORS = ['rgba(0,255,136,', 'rgba(0,229,204,', 'rgba(0,212,255,', 'rgba(74,222,128,'];

  class Particle {
    constructor() { this.reset(true); }
    reset(init = false) {
      this.x = Math.random() * W;
      this.y = init ? Math.random() * H : H + 20;
      this.vy = -(0.2 + Math.random() * 0.5);
      this.vx = (Math.random() - 0.5) * 0.3;
      this.size = 9 + Math.random() * 7;
      this.alpha = 0.03 + Math.random() * 0.07;
      this.base = BASES[Math.floor(Math.random() * 4)];
      this.colorIdx = Math.floor(Math.random() * COLORS.length);
      this.life = 0;
      this.maxLife = 300 + Math.random() * 400;
      this.wobble = Math.random() * Math.PI * 2;
      this.wobbleSpeed = 0.01 + Math.random() * 0.02;
    }
    update() {
      this.wobble += this.wobbleSpeed;
      this.x += this.vx + Math.sin(this.wobble) * 0.3;
      this.y += this.vy;
      this.life++;
      if (this.y < -20 || this.life > this.maxLife) this.reset();
    }
    draw() {
      ctx.save();
      ctx.globalAlpha = this.alpha;
      ctx.fillStyle = COLORS[this.colorIdx] + '1)';
      ctx.font = `${this.size}px "IBM Plex Mono", monospace`;
      ctx.fillText(this.base, this.x, this.y);
      ctx.restore();
    }
  }

  // Connection lines between nearby particles
  class Node {
    constructor() {
      this.x = Math.random() * W;
      this.y = Math.random() * H;
      this.vx = (Math.random() - 0.5) * 0.4;
      this.vy = (Math.random() - 0.5) * 0.4;
      this.r = 2 + Math.random() * 2;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      if (this.x < 0 || this.x > W) this.vx *= -1;
      if (this.y < 0 || this.y > H) this.vy *= -1;
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,255,136,0.12)';
      ctx.fill();
    }
  }

  // Init
  for (let i = 0; i < 60; i++) particles.push(new Particle());
  const NODES_COUNT = 25;
  const nodes = Array.from({ length: NODES_COUNT }, () => new Node());

  function drawConnections() {
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 140) {
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.strokeStyle = `rgba(0,255,136,${0.04 * (1 - dist / 140)})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    }
  }

  function animate() {
    ctx.clearRect(0, 0, W, H);

    nodes.forEach(n => { n.update(); n.draw(); });
    drawConnections();
    particles.forEach(p => { p.update(); p.draw(); });

    requestAnimationFrame(animate);
  }
  animate();
})();


/* ─── NAVIGATION ────────────────────────────────────────────────── */
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.dataset.page;
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`page-${target}`).classList.add('active');
    if (target === 'history') loadHistory();
  });
});


/* ─── SEQUENCE INPUT LOGIC ──────────────────────────────────────── */
const seqInput    = document.getElementById('seqInput');
const labelInput  = document.getElementById('labelInput');
const charCount   = document.getElementById('charCount');
const classifyBtn = document.getElementById('classifyBtn');
const clearBtn    = document.getElementById('clearBtn');
const errorBox    = document.getElementById('errorBox');

seqInput.addEventListener('input', () => {
  // Filter to ATGC only
  const raw = seqInput.value.toUpperCase().replace(/[^ATGC\n\r\s]/g, '');
  if (raw !== seqInput.value) seqInput.value = raw;

  const clean = raw.replace(/\s/g, '');
  charCount.textContent = `${clean.length} bp`;
  classifyBtn.disabled = clean.length < 10;

  updateBaseBars(clean);
  hideError();
});

clearBtn.addEventListener('click', () => {
  seqInput.value = '';
  charCount.textContent = '0 bp';
  classifyBtn.disabled = true;
  updateBaseBars('');
  hideError();
});

// Sample sequence buttons
document.querySelectorAll('.sample-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    seqInput.value = btn.dataset.seq;
    seqInput.dispatchEvent(new Event('input'));
  });
});

function updateBaseBars(seq) {
  const total = seq.length || 1;
  const counts = { A: 0, T: 0, G: 0, C: 0 };
  for (const ch of seq) { if (counts[ch] !== undefined) counts[ch]++; }
  ['A','T','G','C'].forEach(b => {
    const pct = Math.round(counts[b] / total * 100);
    document.getElementById(`bar${b}`).style.width = (seq.length ? pct : 0) + '%';
    document.getElementById(`pct${b}`).textContent = seq.length ? pct + '%' : '0%';
  });
}

function showError(msg) {
  errorBox.textContent = '⚠ ' + msg;
  errorBox.hidden = false;
}
function hideError() { errorBox.hidden = true; }


/* ─── CLASSIFY ──────────────────────────────────────────────────── */
classifyBtn.addEventListener('click', classifySequence);

async function classifySequence() {
  const sequence = seqInput.value.replace(/\s/g, '').toUpperCase();
  const label    = labelInput.value.trim() || 'Unlabeled';

  setLoading(true);
  hideError();

  try {
    const res = await fetch(`${API}/classify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sequence, label })
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || `HTTP ${res.status}`);
    }

    const data = await res.json();
    renderResult(data);

  } catch (e) {
    showError(e.message || 'Cannot connect to backend. Make sure it is running on port 8000.');
  } finally {
    setLoading(false);
  }
}

function setLoading(on) {
  const inner  = classifyBtn.querySelector('.btn-inner');
  const loader = classifyBtn.querySelector('.btn-loader');
  inner.hidden  = on;
  loader.hidden = !on;
  classifyBtn.disabled = on;
}


/* ─── RENDER RESULT ─────────────────────────────────────────────── */
function renderResult(data) {
  const { classification, features } = data;

  // Show result panel
  document.getElementById('emptyState').hidden = true;
  const content = document.getElementById('resultContent');
  content.hidden = false;

  // Force re-animation
  content.style.animation = 'none';
  content.offsetHeight; // reflow
  content.style.animation = '';

  // Type badge
  document.getElementById('resultTypeBadge').textContent = classification.sequence_type || 'Unknown';

  // Organism
  document.getElementById('resultOrganism').textContent = classification.organism_guess || '';

  // Confidence arc
  const confPct = parseInt(classification.confidence) || 0;
  document.getElementById('confNum').textContent = confPct + '%';
  const arc = document.getElementById('confArc');
  const circumference = 2 * Math.PI * 40; // r=40
  arc.style.strokeDasharray = circumference;
  // Trigger animation
  setTimeout(() => {
    arc.style.strokeDashoffset = circumference * (1 - confPct / 100);
    // Color based on confidence
    if (confPct >= 75)      arc.style.stroke = 'var(--green)';
    else if (confPct >= 50) arc.style.stroke = 'var(--teal)';
    else                    arc.style.stroke = 'var(--amber)';
  }, 50);

  // Stats
  document.getElementById('resultSummary').textContent  = classification.summary || '';
  document.getElementById('statGC').textContent         = features.gc_content + '%';
  document.getElementById('statAT').textContent         = features.at_content + '%';
  document.getElementById('statLen').textContent        = features.length + ' bp';
  document.getElementById('statDisease').textContent    = (classification.disease_relevance || 'None').slice(0, 18);

  // GC interp & func pred
  document.getElementById('gcInterp').textContent  = classification.gc_interpretation || '—';
  document.getElementById('funcPred').textContent  = classification.functional_prediction || '—';

  // Mutation flags
  const mutSection = document.getElementById('mutSection');
  const mutList    = document.getElementById('mutList');
  const flags = classification.mutation_flags || [];
  if (flags.length > 0) {
    mutSection.hidden = false;
    mutList.innerHTML = flags.map(f => `<li>${f}</li>`).join('');
  } else {
    mutSection.hidden = true;
  }

  // K-mer bars
  const kmerContainer = document.getElementById('kmerBars');
  kmerContainer.innerHTML = '';
  const kmers = features.top_kmers || {};
  const maxCount = Math.max(...Object.values(kmers), 1);
  Object.entries(kmers).slice(0, 6).forEach(([kmer, count]) => {
    const pct = Math.round((count / maxCount) * 100);
    const row = document.createElement('div');
    row.className = 'kmer-row';
    row.innerHTML = `
      <span class="kmer-label">${kmer}</span>
      <div class="kmer-track"><div class="kmer-fill" style="width:0%" data-pct="${pct}"></div></div>
      <span class="kmer-count">${count}</span>
    `;
    kmerContainer.appendChild(row);
  });
  // Animate bars in
  setTimeout(() => {
    kmerContainer.querySelectorAll('.kmer-fill').forEach(bar => {
      bar.style.width = bar.dataset.pct + '%';
    });
  }, 100);

  // Recommendations
  const recList = document.getElementById('recList');
  const recs = classification.recommendations || [];
  recList.innerHTML = recs.map(r => `<li>${r}</li>`).join('');

  // Scroll result panel into view on mobile
  if (window.innerWidth < 860) {
    document.getElementById('resultPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}


/* ─── HISTORY ───────────────────────────────────────────────────── */
async function loadHistory() {
  const list     = document.getElementById('historyList');
  const empty    = document.getElementById('histEmpty');
  const countEl  = document.getElementById('histCount');

  list.innerHTML = '';

  try {
    const res  = await fetch(`${API}/history`);
    const data = await res.json();

    countEl.textContent = `${data.length} record${data.length !== 1 ? 's' : ''}`;

    if (data.length === 0) {
      empty.hidden = false;
      return;
    }
    empty.hidden = true;

    data.forEach((item, idx) => {
      const el = document.createElement('div');
      el.className = 'hist-item';
      el.style.animationDelay = `${idx * 0.05}s`;

      const date = new Date(item.created_at).toLocaleDateString('en-IN', {
        day: '2-digit', month: 'short', year: 'numeric'
      });

      el.innerHTML = `
        <div class="hist-row">
          <div class="hist-dot"></div>
          <div class="hist-info">
            <div class="hist-type">${item.classification.sequence_type || 'Unknown'}</div>
            <div class="hist-seq">${item.label} · ${item.sequence}</div>
          </div>
          <div class="hist-meta">
            <span class="hist-conf">${item.classification.confidence || '—'}</span>
            <span class="hist-date">${date}</span>
            <span class="hist-toggle">▼</span>
          </div>
        </div>
        <div class="hist-detail">
          <p class="hist-summary">${item.classification.summary || ''}</p>
          <div class="hist-tags">
            <span class="hist-tag">GC: ${item.classification.gc_interpretation ? item.classification.gc_interpretation.slice(0,40) + '...' : '—'}</span>
            <span class="hist-tag">Organism: ${item.classification.organism_guess || '—'}</span>
            <span class="hist-tag">Disease: ${item.classification.disease_relevance || 'None'}</span>
          </div>
        </div>
      `;

      // Toggle detail
      const row    = el.querySelector('.hist-row');
      const detail = el.querySelector('.hist-detail');
      const toggle = el.querySelector('.hist-toggle');

      row.addEventListener('click', () => {
        const isOpen = detail.classList.contains('open');
        detail.classList.toggle('open', !isOpen);
        toggle.classList.toggle('open', !isOpen);
      });

      list.appendChild(el);
    });

  } catch {
    countEl.textContent = '—';
    empty.hidden = false;
    empty.querySelector('p').textContent = 'Could not load history. Is the backend running?';
  }
}

document.getElementById('clearHistBtn').addEventListener('click', async () => {
  if (!confirm('Clear all analysis history?')) return;
  try {
    await fetch(`${API}/history`, { method: 'DELETE' });
    loadHistory();
  } catch {
    alert('Could not clear history.');
  }
});
