import google.generativeai as genai
import json
import os
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-1.5-flash")

def build_prompt(sequence: str, features: dict) -> str:
    return f"""
You are an expert bioinformatics AI. Analyze the following DNA sequence and return a detailed classification.

DNA Sequence: {sequence}

Pre-computed Features:
- Length: {features['length']} bases
- GC Content: {features['gc_content']}%
- AT Content: {features['at_content']}%
- Base Composition: {json.dumps(features['base_composition'])}
- Top 3-mer frequencies: {json.dumps(features['top_kmers'])}
- Detected repeats: {json.dumps(features['repeats'])}

Based on this, provide a JSON response with EXACTLY this structure (no markdown, no backticks, raw JSON only):

{{
  "sequence_type": "one of: Coding Region / Non-coding Region / Promoter Region / Repetitive Element / Unknown",
  "organism_guess": "likely organism or domain (e.g., Bacteria, Eukaryote, Virus, Unknown)",
  "gc_interpretation": "what the GC content suggests biologically",
  "mutation_flags": ["list any suspicious patterns or possible mutations"],
  "disease_relevance": "any potential disease association or 'None detected'",
  "functional_prediction": "predicted biological function",
  "confidence": "percentage like 87%",
  "summary": "2-3 sentence plain English explanation for a student",
  "recommendations": ["list of 2-3 next steps for further analysis"]
}}
"""

async def classify_with_gemini(sequence: str, features: dict) -> dict:
    try:
        prompt = build_prompt(sequence, features)
        response = model.generate_content(prompt)
        raw = response.text.strip()

        # Clean up if Gemini wraps in markdown
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip()

        result = json.loads(raw)
        return result

    except json.JSONDecodeError:
        return {
            "sequence_type": "Unknown",
            "organism_guess": "Unknown",
            "gc_interpretation": "Could not parse response",
            "mutation_flags": [],
            "disease_relevance": "None detected",
            "functional_prediction": "Unable to determine",
            "confidence": "0%",
            "summary": response.text if 'response' in dir() else "Gemini returned an unparseable response.",
            "recommendations": ["Try again with a longer or cleaner sequence"]
        }
    except Exception as e:
        raise Exception(f"Gemini API error: {str(e)}")
